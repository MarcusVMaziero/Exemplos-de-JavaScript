var _linha = null; // variavel global

$(document).ready(function(){

	$('#Casa').hide();
	$('#Apto').hide();
	$('#GridCasa').hide();
	$('#GridCasaD').hide();
	$('#GridApto').hide();
	$('#GridAptoD').hide();     

	$("#inputGroupSelect01").change(function(){

		var imovel = $("#inputGroupSelect01").val();
		if(imovel == "1"){
			$('#Casa').show();
			$('#Apto').hide();
			$('#GridCasas').show(); 
		}if(imovel == "2"){
			$('#Apto').show(); 
			$('#GridApto').show(); 
			$('#Casa').hide();
		}if(imovel == ""){
			$('#Casa').hide();
			$('#Apto').hide();
		}

	});

	$("#btnSalvarC").click(function(){
		var btn = $("#btnSalvarC").val();
		if(btn == "Salvar"){

			AddCasa();
		}
		if(btn == "Atualizar"){

			$(_linha).remove();

			AddCasa();
		}
		$('#FormCasa input[type=text]').val("");

	});

	$("#btnSalvarA").click(function(){
		var btn = $("#btnSalvarA").val();
		if(btn == "Salvar"){

			AddApto();
		}
		if(btn == "Atualizar"){

			$(_linha).remove();

			AddApto();
		}
		$('#FormApto input[type=text]').val("");

	});

});

function CasaEdit(button_edit){
	_linha = $(button_edit).parents("tr");
	var cols = _linha.children("td");

	$("#txtEnderecoC").val($(cols[0]).text());
	$("#txtNumeroC").val($(cols[1]).text());
	$("#txtComplementoC").val($(cols[2]).text());
	$("#txtTelefoneC").val($(cols[3]).text());

	$("#btnSalvarC").val("Atualizar");
}

function AddCasa(){

	$('#GridCasa').show();
	$('#GridCasaD').show();

	if ($("#GridCasa tbody").length == 0){
		$("#GridCasa").append("<tbody></tbody>");
	}

	$("#GridCasa tbody").append(
		"<tr>" +
		"<td>" + $("#txtEnderecoC").val() + "</td>" +
		"<td>" + $("#txtNumeroC").val() + "</td>" +
		"<td>" + $("#txtComplementoC").val() + "</td>" +
		"<td>" + $("#txtTelefoneC").val() + "</td>" +
		"<td>" +
		"<input type='button' " +
		"onclick='CasaEdit(this);' " +
		"class='btn btn-warning' id='btnEditarC' value='Editar'>" +
		"</td> <td><input type='button' " +
		"onclick='DeleteCasa(this);' " +
		"class='btn btn-danger' id='btnExcluirC' value='Excluir'>" +
		"</td>" +
		"</tr>"
		);
}
function AddApto(){

	$('#GridApto').show();
	$('#GridAptoD').show();

	if ($("#GridApto tbody").length == 0){
		$("#GridApto").append("<tbody></tbody>");
	}

	$("#GridApto tbody").append(
		"<tr>" +
		"<td>" + $("#txtEnderecoA").val() + "</td>" +
		"<td>" + $("#txtNumeroA").val() + "</td>" +
		"<td>" + $("#txtComplementoA").val() + "</td>" +
		"<td>" + $("#txtTelefoneA").val() + "</td>" +
		"<td>" + $("#txtDataA").val() + "</td>" +
		"<td>" + $("#txtValorA").val() + "</td>" +
		"<td>" + $("input[id=garagem]:checked").val() + "</td>" +
		"<td>" + $("input[id=piscina]:checked").val() + "</td>" +
		"<td>" + $("input[id=quadra]:checked").val() + "</td>" +
		"<td>" +
		"<input type='button' " +
		"onclick='AptoEdit(this);' " +
		"class='btn btn-warning' id='btnEditarA' value='Editar'>" +
		"</td> <td><input type='button' " +
		"onclick='DeleteApto(this);' " +
		"class='btn btn-danger' id='btnExcluirA' value='Excluir'>" +
		"</td>" +
		"</tr>"
		);
}

function AptoEdit(button_edit){
	_linha = $(button_edit).parents("tr");
	var cols = _linha.children("td");

	$("#txtEnderecoA").val($(cols[0]).text());
	$("#txtNumeroA").val($(cols[1]).text());
	$("#txtComplementoA").val($(cols[2]).text());
	$("#txtTelefoneA").val($(cols[3]).text());
	$("#txtDataA").val($(cols[4]).text());
	$("#txtValorA").val($(cols[5]).text());
	$("input[id=garagem]:checked").val($(cols[6]).text());
	$("input[id=piscina]:checked").val($(cols[7]).text());
	$("input[id=quadra]:checked").val($(cols[8]).text());

	$("#btnSalvarA").val("Atualizar");
}
function DeleteCasa(button_delete){
	_linha = $(button_delete).parents("tr");
	$(_linha).remove();

	var ver = $("#GridCasa").length;

	alert(ver);
	
}
function DeleteApto(button_delete){
	_linha = $(button_delete).parents("tr");
	$(_linha).remove();

	var ver = $("#GridApto").length;

	if(ver == 1){
		$("#GridCasa").hide();
	}
	
}