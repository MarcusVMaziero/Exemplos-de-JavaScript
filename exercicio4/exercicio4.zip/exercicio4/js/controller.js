var _linha = null; // variavel global

$(document).ready(function(){

	$('#PessoaJ').hide();
	$('#PessoaS').hide();
	$('#PessoaF').hide();
	$('#GridPf').hide();
	$('#GridPs').hide();
	$('#GridPessoaS').hide();
	$('#GridPJ').hide();


	$("#inputGroupSelect01").change(function(){

		var verifica = $("#inputGroupSelect01").val();
		if(verifica == "1"){
			$('#PessoaF').show();
			$('#dependentesPf').hide();
			$('#PessoaJ').hide();
			$('#GridPJ').hide();
			$('#PessoaS').hide();
			$('#GridPs').hide();
			$('#GridPessoaS').hide();
		}if(verifica == "2"){
			$('#PessoaS').hide();
			$('#PessoaF').hide();
			$('#PessoaJ').show();
			$('#maiorLimite').hide();
			$('#GridPf').hide(); 
		}if(verifica == "3"){
			$('#PessoaS').show();
			$('#PessoaF').hide();
			$('#PessoaJ').hide();
			$('#GridPJ').hide();
			$('#GridPf').hide();
		}if(verifica == ""){

			$('#PessoaJ').hide();
			$('#PessoaS').hide();
			$('#PessoaF').hide();
			$('#GridPf').hide();
			$('#GridPs').hide();
			$('#GridPessoaS').hide();
			$('#GridPJ').hide();
		}

	});
/////////////////////////////////////////////////PESSOA FISICA ///////////////////////////
	//Select da pessoa fisica

	$("#dependentesF").change(function(){

		var verifica = $("#dependentesF").val();
		if(verifica == "nao"){
			$('#dependentesPf').hide();
			$('#referenciaF').show();
		}if(verifica == "sim"){
			$('#referenciaF').hide();
			$('#dependentesPf').show();
		}

	});
	// botão salvar pessoa fisica
	$("#btnSalvarF").click(function(){
		var btn = $("#btnSalvarF").val();


		AddPessoaF();
		$('#FormPessoaF input[type=text]').val("");

	});

///////////////////////////////////PESSOA SEM CONTA //////////////////////////

	// botão salvar pessoa fisica
	$("#btnSalvarS").click(function(){
		var btn = $("#btnSalvarS").val();


		AddPessoaS();
		$('#FormPessoaS input[type=text]').val("");

	});

/////////////////////////////////////////////////PESSOA JURIDICA ///////////////////////////
	//Select da pessoa juridica

	$("#limite").change(function(){

		var valor = $("#limite").val();
		if(valor == "1"){
			$('#menorlimite').show();
			$('#maiorLimite').hide();
		}if(valor == "2"){
			$('#menorlimite').hide();
			$('#maiorLimite').show();
		}

	});

	// botão salvar pessoa juridica
	$("#btnSalvarJ").click(function(){
		var btn = $("#btnSalvarJ").val();


		AddPessoaJ();
		$('#FormPessoaJ input[type=text]').val("");

	});

//////////////////////////////////////////////////////MASCARAS //////////////////////////////////
$('#FormPessoa input[name=telefone]').mask("(99) 9999-9999");
$('#FormPessoa input[name=cpf]').mask("000.000.000-00");
//$("#txtTelefoneA").mask("(99) 9999-9999");
//$("#txtDataA").mask("00/00/0000");
$('#FormPessoa input[name=valor]').mask('#.##0,00', {
	reverse: true
});

$("#sair").click(function(){

	window.location.replace("Index.html");
});
});
/////////PESSOA FISICA ////////////////////
function AddPessoaF(){
	

	$('#GridPf').show();
	$('#GridPessoaF').show();
	
	if ($("#GridPessoaF tbody").length == 0){
		$("#GridPessoaF").append("<tbody></tbody>");
	}
	$("#GridPessoaF tbody").append(
		"<tr>" +
		"<td>" + $("#txtNomeF").val() + "</td>" +
		"<td>" + $("#txtEnderecoF").val() + "</td>" +
		"<td>" + $("#txtTelefoneF").val() + "</td>" +
		"<td>" + $("#dependentesF").val() + "</td>" +
		"<td>" +
		"</td> <td><input type='button' " +
		"onclick='DeletePessoaF(this);' " +
		"class='btn btn-danger' id='btnExcluirC' value='Excluir'>" +
		"</td>" +
		"</tr>"
		);
}
function DeletePessoaF(button_delete){
	_linha = $(button_delete).parents("tr");
	$(_linha).remove();

	var ver = $("#GridPessoaF").length;

}
//////////////////////////////// PESSOA SEM CONTA ///////////////////
function AddPessoaS(){
	
	$('#GridPs').show();
	$('#GridPessoaS').show();
	
	if ($("#GridPessoaS tbody").length == 0){
		$("#GridPessoaS").append("<tbody></tbody>");
	}

	$("#GridPessoaS tbody").append(
		"<tr>" +
		"<td>" + $("#txtNomeS").val() + "</td>" +
		"<td>" + $("#txtTelefoneS").val() + "</td>" +
		"<td>" + $("#txtCpfS").val() + "</td>" +
		"<td><input type='button' " +
		"onclick='DeletePessoaS(this);' " +
		"class='btn btn-danger' id='btnExcluirS' value='Excluir'>" +
		"</td>" +
		"</tr>"
		);
}
function DeletePessoaS(button_delete){
	_linha = $(button_delete).parents("tr");
	$(_linha).remove();

	var ver = $("#GridPessoaS").length;
	
}
/////////PESSOA JURIDICA ////////////////////
function AddPessoaJ(){
	

	$('#GridPJ').show();
	$('#GridPessoaJ').show();
	
	if ($("#GridPessoaJ tbody").length == 0){
		$("#GridPessoaJ").append("<tbody></tbody>");
	}
	$("#GridPessoaJ tbody").append(
		"<tr>" +
		"<td>" + $("#txtNomeJ").val() + "</td>" +
		"<td>" + $("#txtEnderecoJ").val() + "</td>" +
		"<td>" + $("#txtTelefoneJ").val() + "</td>" +
		"<td><input type='button' " +
		"onclick='DeletePessoaJ(this);' " +
		"class='btn btn-danger' id='btnExcluirJ' value='Excluir'>" +
		"</td>" +
		"</tr>"
		);
}
function DeletePessoaJ(button_delete){
	_linha = $(button_delete).parents("tr");
	$(_linha).remove();

	var ver = $("#GridPessoaJ").length;
	
}