var valores = [];
$(document).ready(function(){

	$('#visualiza').hide();  

	//Cria um array com 3 itens podendo ser adicionados mais e assim respectivamente serão adicionados na table de itens

	var produtos = ["impressora", "carro", "casa", "shampoo", "caneta", "lapis", "celular", "arroz"];

	//For que percorre o array e exibe ele dentro da table
	produtos.forEach(function(item){
		var lista =  document.getElementById("Grid").innerHTML ;
		lista += "<tr> <td> <input type='radio' id='radio' name='"+item+"' value='"+item+"'/></td><td>"+ item + "</td> </tr>";
		document.getElementById("Grid").innerHTML = lista;
	});
	//ao clicar no input radio executa essas tarefas descritas abaixo
	$("input[id=radio]:radio").click(function()
	{
		var nome = $(this).val();

		var image = "img/"+nome+".jpg";

		$("#produto").val(nome);
		$("#valor").val(Math.floor(Math.random() * 1000));
		$("#unidade").val("Casas Bahia Londrina");
		$("#quantidade").val(1);
		$('#img').attr('src', image);

		$('#visualiza').show();
		
	});

	

	$("#SalvaGrid").click(function(){

		//Caso for comprar pega os valores e lança na grid de baixo inserindo os valores dentro de um array chamado valores
		if(Valida()){

			var nome_produto = $("#produto").val();
			var quantidade_com = $("#quantidade").val();
			var valor = $("#valor").val();

			var soma = valor * quantidade_com;

			valores.push(soma);

			AtualizaValor();



			var popula = document.getElementById("GridCalcula").innerHTML;

			popula += "<tr> <td> <input type='text' value='"+ quantidade_com +"'/> </td> " +

			"<td> <input type='text' value='"+ nome_produto +"'/> </td> "+
			"<td> <input type='text' value='"+ valor +"'/> </td> "+
			"<td> <input type='text' id='valor_f' value='"+ soma+"'/> </td>"+
			"<td> <button class='btn btn-danger' type='button' id='excluir'onclick='ExcluirItens(this.parentNode.parentNode.rowIndex)'>Excluir</button></td></tr>";
			document.getElementById("GridCalcula").innerHTML = popula;
			
		}

		$("#finalizar").click(function()
		{
			var desconto = $("#desconto").val();
			var final = $("#resultado").text();

			var resulta = (final*desconto)/100;

			resulta = final - resulta;

			if(confirm("Sua compra fica no valor de: "+resulta)){
				alert('Compra realizada com Sucesso');
				location.reload();
			}
			else{ alert('Compra Cancelada');
		}
	});

	});




});
function ExcluirItens(i){

	var valor_f = $("#valor_f").val();
	//For que percorre o array e exclui o item do array em seguida exclui o item da table e atualiza o valor total
	for (var d = 0; d < valores.length; d++) {
		if (valores[d] == valor_f){
			valores.splice(d, 1);
		}
	}
	
	document.getElementById('GridCalcula').deleteRow(i);
	var atual = $("#resultado").text();

	var valor_f = atual - valor_f;

	$("#resultado").text(valor_f);
}
function Valida(){

	var a1 = $('#produto').val();
	var a2 = $('#unidade').val();
	var a3 = $('#valor').val();
	var a4 = $('#quantidade').val();

	if(a1 == "" || a2 == "" || a3 == "" || a4 < 1){
		alert("Favor preencher todos os campos!");

		return false;
	}else{
		return true;
	}

}
function AtualizaValor(){

	var total = valores.reduce(function(antes, atual) {
		var result = antes + atual;
		return result;
	});
	$("#resultado").text(total);
}